package Server;


public class DataFileException extends Exception {



	public DataFileException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}


}
