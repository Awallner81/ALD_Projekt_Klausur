package Server_Route_Planner;

import java.awt.DisplayMode;
import java.io.BufferedReader;
<<<<<<< HEAD
import java.io.FileReader;
import java.io.IOException;
=======
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Date;
>>>>>>> origin/master
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
<<<<<<< HEAD
				
		 Scanner scanner = null;
		 BinarySearchTree meinBST = new BinarySearchTree();
		 Ort ort = new Ort( 0, null);
            try {
                scanner = new Scanner(new BufferedReader(new FileReader("orte.txt")));
                //scanner.useDelimiter(",");
                
                
                while(scanner.hasNextLine()) {

                    String input = scanner.nextLine();
                    String[] data = input.split(",");
                    int id = Integer.parseInt(data[0]);
                    String name = data[1];
                    //System.out.println(id + ": " + name);
                    ort = new Ort(id,name);
                    meinBST.insert(ort);; 
                	  
                	
                  
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if(scanner != null) {
                    scanner.close();
                }
            } 
=======
>>>>>>> origin/master

		Scanner scanner = null;
		BinarySearchTree meinBST = new BinarySearchTree();
		BST tree = new BST();
		try {
			scanner = new Scanner(new BufferedReader(new FileReader("orte.txt")));
			// scanner.useDelimiter(",");

			while (scanner.hasNextLine()) {

				String input = scanner.nextLine();
				String[] data = input.split(",");
				int id = Integer.parseInt(data[0]);
				String name = data[1];
				Object value = data[1];
				System.out.println(id + ": " + name);
				tree.put(id, name, value);

			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (scanner != null) {
				scanner.close();
			}
		}

		//String suche = "Linz";

		//System.out.println("Suche " + suche);
		//System.out.println(meinBST.findExact(suche));

		// System.out.println("ID von "+ suche +" = " +Ergebnis.getId());

		// tree.put( "f", "eff" );
		// tree.put( "c", "sea" );
		// tree.put( "a", "aye" );
		// tree.put( "e", "eee" );
		// tree.put( "i", "eye" );
		// tree.put( "h", "aitch" );
		// tree.put( "z", "zed" );

		//for (int i = 0; i < 6; i++) {
			
		//System.out.println(tree.get(i));
		//String name = tree.get(i);
		//System.out.println(tree.getID(name));
		//}
		
		System.out.println("Key to Name ");
		String str = tree.get(0); // str will equal "eye"
		System.out.println("suche 0 =" +str);

		str = tree.get(2); // str will equal "eye updated"
		System.out.println("suche 2 =" + str);
		str = tree.get(6); // str will equal "eye updated"
		System.out.println("suche 6 =" + str);
		System.out.println("");
		
		System.out.println("Name to Key");
		
<<<<<<< HEAD
	  
	
        String suche="graz";
        
        System.out.println("Suche " + suche);
        Ort Ergebnis = meinBST.findExact(suche);
        
       System.out.println("ID von "+ suche +" = " +Ergebnis);
      
       
	
   	}
	
	}
=======
		//int id1 =  tree.getI("GRAZ"); // str will equal "eye"
		//System.out.println("suche GRAZ: " + id1);
	
		
		int id2 = tree.getI("Wien"); // str will equal "eye"
		System.out.println("suche Wien "+ id2);
		
		//int id3 = tree.getID("Linz"); // str will equal "eye"
		//System.out.println("suche Linz "+ id3);
		
		
	
		//System.err.println(tree.findID("Linz"));
	   

	  

}
}
>>>>>>> origin/master
