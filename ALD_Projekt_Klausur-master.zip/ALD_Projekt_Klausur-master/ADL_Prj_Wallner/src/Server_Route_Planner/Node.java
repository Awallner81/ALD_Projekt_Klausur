package Server_Route_Planner;


	public class Node {

		
			 	String data; 
			 	Node left; 
			 	Node right;
			 
			 	public Node(String data){ 
			 		this.data = data; 
			 		left = null; 
			 		right = null; 
			 	} 
		 } 


	
