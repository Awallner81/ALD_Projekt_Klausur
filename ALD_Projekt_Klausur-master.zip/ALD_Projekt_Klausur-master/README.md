# ALD_Projekt_Klausur

# Erstes GitHub Repository
### Lehrveranstaltung: ALD
### Name: Alexnader Wallner
Das ist ein Repository, um das erfolgreiche Setup von github.com und der lokalen Git Installation zu
testen...